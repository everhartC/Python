from django.apps import AppConfig


class ReadsappConfig(AppConfig):
    name = 'readsapp'
