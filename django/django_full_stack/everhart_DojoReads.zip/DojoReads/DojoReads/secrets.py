# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '+95_%1e*4%pue-u1l3#(iu9+i^bw)8r!lc1vfwc0dvh8ll($z-'