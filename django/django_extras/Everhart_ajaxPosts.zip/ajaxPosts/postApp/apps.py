from django.apps import AppConfig


class PostappConfig(AppConfig):
    name = 'postApp'
