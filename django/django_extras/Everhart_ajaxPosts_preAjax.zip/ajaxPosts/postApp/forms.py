from python.django.django_extras.ajaxPosts.postApp.models import User
from django import forms
from .models import User

